class Trade {
  final String instrument;
  final String direction;
  final double entry;
  final double stopLoss;
  final double target;
  final double exit;
  final double positionSize;
  final String notes;
  final DateTime date;

  Trade({
    required this.instrument,
    required this.direction,
    required this.entry,
    required this.stopLoss,
    required this.target,
    required this.exit,
    required this.positionSize,
    required this.notes,
    required this.date,
  });

  // Calculate PnL based on direction
  double get pnl {
    if (direction.toLowerCase() == 'buy') {
      return (exit - entry) * positionSize;
    } else {
      return (entry - exit) * positionSize;
    }
  }

  // Get trade result (Win/Loss)
  String get result => pnl >= 0 ? "Profit" : "Loss";

  // Calculate planned RRR (based on entry, SL and target)
  String get plannedRRR {
    if (stopLoss == 0) return "N/A";
    
    double risk = (direction.toLowerCase() == 'buy') 
        ? (entry - stopLoss).abs() 
        : (stopLoss - entry).abs();
        
    double reward = (direction.toLowerCase() == 'buy') 
        ? (target - entry).abs() 
        : (entry - target).abs();
        
    double ratio = reward / risk;
    return "1:${ratio.toStringAsFixed(2)}";
  }

  // Calculate actual RRR (based on entry, SL and exit)
  String get actualRRR {
    if (stopLoss == 0) return "N/A";
    
    double risk = (direction.toLowerCase() == 'buy') 
        ? (entry - stopLoss).abs() 
        : (stopLoss - entry).abs();
        
    // For XAUUSD, use different calculation (pips-based)
    if (instrument.toLowerCase().contains('xau') || 
        instrument.toLowerCase().contains('gold')) {
      // XAUUSD specific calculation - using pip value
      double pipValue = positionSize * 0.1; // Simplified calculation
      double pipsGained = (pnl / pipValue).abs();
      double pipsRisked = risk * 10; // Assuming 1$ risk = 10 pips
      
      double ratio = pipsRisked > 0 ? pipsGained / pipsRisked : 0;
      return "1:${ratio.toStringAsFixed(2)}";
    } else {
      // Standard calculation for other instruments
      double reward = (direction.toLowerCase() == 'buy') 
          ? (exit - entry).abs() 
          : (entry - exit).abs();
          
      double ratio = reward / risk;
      return "1:${ratio.toStringAsFixed(2)}";
    }
  }

  // Calculate at which RRR the trade was exited
  String get exitRRR {
    if (stopLoss == 0) return "N/A";
    
    double risk = (direction.toLowerCase() == 'buy') 
        ? (entry - stopLoss).abs() 
        : (stopLoss - entry).abs();
        
    double rewardAtExit = (direction.toLowerCase() == 'buy') 
        ? (exit - entry).abs() 
        : (entry - exit).abs();
        
    double ratio = rewardAtExit / risk;
    return "1:${ratio.toStringAsFixed(2)}";
  }

  // Get numeric RRR values for calculations
  double get plannedRRRNumeric {
    if (stopLoss == 0) return 0;
    
    double risk = (direction.toLowerCase() == 'buy') 
        ? (entry - stopLoss).abs() 
        : (stopLoss - entry).abs();
        
    double reward = (direction.toLowerCase() == 'buy') 
        ? (target - entry).abs() 
        : (entry - target).abs();
        
    return reward / risk;
  }

  double get actualRRRNumeric {
    if (stopLoss == 0) return 0;
    
    double risk = (direction.toLowerCase() == 'buy') 
        ? (entry - stopLoss).abs() 
        : (stopLoss - entry).abs();
        
    if (instrument.toLowerCase().contains('xau') || 
        instrument.toLowerCase().contains('gold')) {
      double pipValue = positionSize * 0.1;
      double pipsGained = (pnl / pipValue).abs();
      double pipsRisked = risk * 10;
      
      return pipsRisked > 0 ? pipsGained / pipsRisked : 0;
    } else {
      double reward = (direction.toLowerCase() == 'buy') 
          ? (exit - entry).abs() 
          : (entry - exit).abs();
          
      return reward / risk;
    }
  }
}