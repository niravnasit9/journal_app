import 'package:flutter/material.dart';
import 'models/trade.dart';

class TradeRepo {
  final List<Trade> _trades = [];

  List<Trade> get trades => _trades;

  TradeRepo() {
    // Add dummy trades with realistic data
    _addDummyTrades();
  }

  void _addDummyTrades() {
    // BTC Trades (55-60% accuracy, RRR around 1:2.2)
    _trades.addAll([
      Trade(
        instrument: "BTCUSD",
        direction: "Buy",
        entry: 48500.0,
        stopLoss: 48200.0,
        target: 49100.0,
        exit: 49050.0,
        positionSize: 0.5,
        notes: "Strong support at 48k, breakout expected",
        date: DateTime.now().subtract(Duration(days: 1)),
      ),
      Trade(
        instrument: "BTCUSD",
        direction: "Sell",
        entry: 49300.0,
        stopLoss: 49600.0,
        target: 48700.0,
        exit: 48750.0,
        positionSize: 0.3,
        notes: "Resistance at 49.5k, expecting pullback",
        date: DateTime.now().subtract(Duration(days: 2)),
      ),
      Trade(
        instrument: "BTCUSD",
        direction: "Buy",
        entry: 47800.0,
        stopLoss: 47500.0,
        target: 48500.0,
        exit: 47550.0,
        positionSize: 0.4,
        notes: "False breakout, stopped out",
        date: DateTime.now().subtract(Duration(days: 3)),
      ),
      Trade(
        instrument: "BTCUSD",
        direction: "Sell",
        entry: 50200.0,
        stopLoss: 50500.0,
        target: 49500.0,
        exit: 49400.0,
        positionSize: 0.6,
        notes: "Top formation confirmed",
        date: DateTime.now().subtract(Duration(days: 4)),
      ),
      Trade(
        instrument: "BTCUSD",
        direction: "Buy",
        entry: 49600.0,
        stopLoss: 49300.0,
        target: 50200.0,
        exit: 50100.0,
        positionSize: 0.5,
        notes: "Bounce from support level",
        date: DateTime.now().subtract(Duration(days: 5)),
      ),
    ]);

    // XAUUSD Trades (Gold trades with different logic)
    _trades.addAll([
      Trade(
        instrument: "XAUUSD",
        direction: "Buy",
        entry: 1985.0,
        stopLoss: 1978.0,
        target: 2000.0,
        exit: 1998.5,
        positionSize: 1.0,
        notes: "Fed meeting dovish, gold bullish",
        date: DateTime.now().subtract(Duration(days: 1)),
      ),
      Trade(
        instrument: "XAUUSD",
        direction: "Sell",
        entry: 2010.0,
        stopLoss: 2015.0,
        target: 1990.0,
        exit: 1992.0,
        positionSize: 0.8,
        notes: "Overbought conditions, expecting correction",
        date: DateTime.now().subtract(Duration(days: 2)),
      ),
      Trade(
        instrument: "XAUUSD",
        direction: "Buy",
        entry: 1970.0,
        stopLoss: 1965.0,
        target: 1985.0,
        exit: 1966.0,
        positionSize: 1.2,
        notes: "Support break failed, stopped out",
        date: DateTime.now().subtract(Duration(days: 3)),
      ),
      Trade(
        instrument: "XAUUSD",
        direction: "Sell",
        entry: 1995.0,
        stopLoss: 2000.0,
        target: 1980.0,
        exit: 1981.5,
        positionSize: 1.0,
        notes: "Resistance held strong",
        date: DateTime.now().subtract(Duration(days: 4)),
      ),
      Trade(
        instrument: "XAUUSD",
        direction: "Buy",
        entry: 1960.0,
        stopLoss: 1955.0,
        target: 1975.0,
        exit: 1973.0,
        positionSize: 0.9,
        notes: "Bounce from key support level",
        date: DateTime.now().subtract(Duration(days: 5)),
      ),
    ]);

    // ETHUSD Trades
    _trades.addAll([
      Trade(
        instrument: "ETHUSD",
        direction: "Buy",
        entry: 2580.0,
        stopLoss: 2550.0,
        target: 2650.0,
        exit: 2640.0,
        positionSize: 2.0,
        notes: "Ethereum upgrade bullish",
        date: DateTime.now().subtract(Duration(days: 1)),
      ),
      Trade(
        instrument: "ETHUSD",
        direction: "Sell",
        entry: 2620.0,
        stopLoss: 2650.0,
        target: 2550.0,
        exit: 2545.0,
        positionSize: 1.5,
        notes: "Resistance at 2620 held strong",
        date: DateTime.now().subtract(Duration(days: 2)),
      ),
      Trade(
        instrument: "ETHUSD",
        direction: "Buy",
        entry: 2520.0,
        stopLoss: 2490.0,
        target: 2580.0,
        exit: 2495.0,
        positionSize: 1.8,
        notes: "False breakout, market reversed",
        date: DateTime.now().subtract(Duration(days: 3)),
      ),
    ]);

    // More mixed trades for better statistics
    _trades.addAll([
      Trade(
        instrument: "BTCUSD",
        direction: "Sell",
        entry: 51200.0,
        stopLoss: 51500.0,
        target: 50500.0,
        exit: 50400.0,
        positionSize: 0.4,
        notes: "Profit taking at resistance",
        date: DateTime.now().subtract(Duration(days: 6)),
      ),
      Trade(
        instrument: "XAUUSD",
        direction: "Buy",
        entry: 1950.0,
        stopLoss: 1945.0,
        target: 1965.0,
        exit: 1962.0,
        positionSize: 1.1,
        notes: "Safe haven demand increasing",
        date: DateTime.now().subtract(Duration(days: 7)),
      ),
      Trade(
        instrument: "ETHUSD",
        direction: "Sell",
        entry: 2720.0,
        stopLoss: 2750.0,
        target: 2650.0,
        exit: 2660.0,
        positionSize: 1.2,
        notes: "Overbought on daily chart",
        date: DateTime.now().subtract(Duration(days: 8)),
      ),
    ]);
  }

  void add(Trade trade) {
    _trades.add(trade);
  }

  double get totalPnl {
    return _trades.fold(0, (sum, trade) => sum + trade.pnl);
  }

  double get winRate {
    if (_trades.isEmpty) return 0;
    final winningTrades = _trades.where((t) => t.pnl > 0).length;
    return (winningTrades / _trades.length) * 100;
  }

  int get winningTrades => _trades.where((t) => t.pnl > 0).length;
  int get losingTrades => _trades.where((t) => t.pnl < 0).length;
  
  double get averageRRR {
    if (_trades.isEmpty) return 0;
    
    double totalRRR = 0;
    int count = 0;
    
    for (var trade in _trades) {
      double rrr = trade.actualRRRNumeric;
      if (rrr > 0) {
        totalRRR += rrr;
        count++;
      }
    }
    
    return count > 0 ? totalRRR / count : 0;
  }

  // Get trades by instrument
  List<Trade> getTradesByInstrument(String instrument) {
    return _trades.where((trade) => trade.instrument == instrument).toList();
  }

  // Get performance by instrument
  Map<String, double> getPerformanceByInstrument() {
    Map<String, double> performance = {};
    
    for (var trade in _trades) {
      performance.update(
        trade.instrument,
        (value) => value + trade.pnl,
        ifAbsent: () => trade.pnl
      );
    }
    
    return performance;
  }
}